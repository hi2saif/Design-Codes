package com.goibibo.Assignment.Controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

    @RequestMapping(value = "/rules",method = RequestMethod.POST)
    public String defineRules()
    {

        return "sadas";
    }
}
