package enums;

public enum BOOK_STATUS {
    AVAILABLE,
    RESERVED,
    LOANED,
    LOST
}
