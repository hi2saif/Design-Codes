package enums;

public enum ACCOUNT_STATUS {
    ACTIVE,
    CLOSED,
    CANCELED,
    BLACKLISTED,
    NONE
}
