package enums;

public enum RESERVATION_STATUS {
    WAITING,
    PENDING,
    CANCELED,
    NONE
}
