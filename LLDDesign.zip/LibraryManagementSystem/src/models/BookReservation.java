package models;

public class BookReservation {

    public static BookReservation fetchReservationDetails(String barcode) {
        return null;
    }
}
