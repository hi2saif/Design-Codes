package models;

public class BookItem {
}
