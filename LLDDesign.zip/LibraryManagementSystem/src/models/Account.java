package models;

import enums.ACCOUNT_STATUS;

public abstract class Account {
    private String id;
    private String password;
    private ACCOUNT_STATUS account_status;
    private Person person;

    public boolean resetPassword() {
        return false;
    }
}
