public class Main {
    public static void main(String[] args) {


        //User userFirst = new User("123","test",new ROLE("Admin"));
        // User userSecond = new User("456","test2",new ROLE("Guest"));

        String str = "abcd";
        try {
            str=str.substring(0);
        } catch (Exception e) {

        } finally {
            str = str.substring(1);
            System.out.println(str);
        }
    }
}
