package service;

import models.ROLE;
import models.Resource;
import models.User;

public class Driver {

    private ROLE role;

//    public void getAccess(User user1,
//                          String actionType,
//                          Resource resource) {
//
//     //   role = user1.getRole();
//        if(role == ROLE.ADMIN)
//        {
//            System.out.println("You Have Access to this resource" + resource);
//        }
//    }

}
