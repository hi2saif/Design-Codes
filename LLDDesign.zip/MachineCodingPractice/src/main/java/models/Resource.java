package models;

public class Resource {
    private int object1;
    private int object2;
}

