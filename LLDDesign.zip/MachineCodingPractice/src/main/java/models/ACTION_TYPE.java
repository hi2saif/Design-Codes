package models;

public enum ACTION_TYPE {
    READ,WRITE,DELETE
}
