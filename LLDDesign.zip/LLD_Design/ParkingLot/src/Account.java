import enums.AccountStatus;
import models.Person;

public class Account {
    private String userName;
    private String password;
    private AccountStatus status;
    private Person person;

    public boolean resetPassword() {
        return false;
    }

    public class Admin extends Account {
        public boolean addParkingFloor(ParkingFloor floor) {
            return false;
        }

        public boolean addParkingSpot(String floorName, ParkingSpot spot) {
            return false;
        }

        public boolean addParkingDisplayBoard(String floorName, ParkingDisplayBoard displayBoard) {
            return false;
        }

        public boolean addCustomerInfoPanel(String floorName, CustomerInfoPanel infoPanel) {
            return false;
        }

        public boolean addEntrancePanel(EntrancePanel entrancePanel) {
            return false;
        }

        public boolean addExitPanel(ExitPanel exitPanel) {
            return false;
        }
    }

    public class ParkingAttendant extends Account {
        public boolean processTicket(String TicketNumber) {
            return false;
        }
    }
}
