package enums;

public enum ParkingTicketStatus {
    ACTIVE, PAID, LOST
}
