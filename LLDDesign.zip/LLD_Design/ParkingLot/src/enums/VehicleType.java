package enums;

public enum VehicleType {
    CAR, TRUCK, ELECTRIC, VAN, MOTORBIKE
}
