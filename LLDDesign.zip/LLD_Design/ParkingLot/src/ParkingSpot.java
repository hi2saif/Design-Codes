import enums.ParkingSpotType;

public class ParkingSpot {
    private String number;
    private boolean free;
    private Vehicle vehicle;
    private ParkingSpotType type;

    public boolean IsFree() {
        return free;
    }

    public ParkingSpot(ParkingSpotType type) {
        this.type = type;
    }

    public boolean assignVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
        this.free = false;
    }
    public boolean removeVehicle() {
        this.vehicle = null;
        free = true;
    }

    public class HandicappedSpot extends ParkingSpot {
        public HandicappedSpot() {
            super(ParkingSpotType.HANDICAPPED);
        }
    }

    public class CompactSpot extends ParkingSpot {
        public CompactSpot() {
            super(ParkingSpotType.COMPACT);
        }
    }

    public class LargeSpot extends ParkingSpot {
        public LargeSpot() {
            super(ParkingSpotType.LARGE);
        }
    }

    public class MotorbikeSpot extends ParkingSpot {
        public MotorbikeSpot() {
            super(ParkingSpotType.MOTORBIKE);
        }
    }

    public class ElectricSpot extends ParkingSpot {
        public ElectricSpot() {
            super(ParkingSpotType.ELECTRIC);
        }
    }
}
