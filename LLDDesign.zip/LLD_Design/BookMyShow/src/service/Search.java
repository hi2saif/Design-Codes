package service;

import enums.Genre;
import models.Movie;

import java.util.Date;
import java.util.List;

public class Search {
    public List<Movie> searchMoviesByNames(String name) {
        return null;
    }

    public List<Movie> searchMoviesByGenre(Genre genre) {
        return null;
    }

    public List<Movie> searchMoviesByLanguage(String language) {
        return null;
    }

    public List<Movie> searchMoviesByDate(Date releaseDate) {
        return null;
    }
}
