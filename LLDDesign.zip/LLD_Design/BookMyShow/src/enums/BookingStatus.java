package enums;

public enum BookingStatus {
    REQUESTED, PENDING, CONFIRMED, CANCELLED;
}
