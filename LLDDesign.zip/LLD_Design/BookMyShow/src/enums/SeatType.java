package enums;

public enum SeatType {
    DELUX, VIP, ECONOMY, OTHER;
}
