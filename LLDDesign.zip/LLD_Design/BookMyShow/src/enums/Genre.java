package enums;

public enum Genre {
    SCI_FI, DRAMA, ROM_COM, FANTASY;
}
