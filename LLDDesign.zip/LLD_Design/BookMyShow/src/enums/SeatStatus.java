package enums;

public enum SeatStatus {
    BOOKED, AVAILABLE, RESERVED, NOT_AVAILABLE;
}
