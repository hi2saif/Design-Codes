package models;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class Cinema {
    int cinemaHallId;
    String cinemaHallName;
    City address;
    int numberOfHalls;

    List<CinemaHall> audiList;

    public Map<Date, Movie> getMovies(List<Date> dateList) {
        return null;
    }

    public Map<Date, Show> getShows(List<Date> dateList) {
        return null;
    }
}
