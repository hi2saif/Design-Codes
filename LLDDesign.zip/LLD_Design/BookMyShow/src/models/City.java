package models;

public class City {
    int pinCode; //ZipCode
    String street;
    String cityName;
    String state;
    String country;
}
