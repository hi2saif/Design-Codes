package models;

public class SystemMember extends User {
    Account account;
    String name;
    String email;
    City address;
}
