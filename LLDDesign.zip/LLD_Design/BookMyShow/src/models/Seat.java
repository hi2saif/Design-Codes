package models;

import enums.SeatStatus;
import enums.SeatType;

public class Seat {
    int seatId;
    int seatNumber;
    SeatType seatType;
    SeatStatus seatStatus;
    Double price;
}
