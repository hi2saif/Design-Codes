package models;

public class Admin  extends SystemMember{
    public boolean addMovie(Movie moivie) {
        return false;
    }

    public boolean addShow(Show show) {
        return false;
    }
}
