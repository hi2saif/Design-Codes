package models;

import enums.Genre;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class Movie {
    String movieName;
    int movieId;
    int durationInMins;
    String language;
    Genre genre;
    Date releaseDate;
    Map<String, List<Show>> cityShowMap;  //Given a Movie depict all the shows in the city
}
