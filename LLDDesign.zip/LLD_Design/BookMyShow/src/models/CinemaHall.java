package models;

import java.util.List;

public class CinemaHall {
    int audiId;
    String audiName;
    int totalSeats;

    List<Show> shows;
}
