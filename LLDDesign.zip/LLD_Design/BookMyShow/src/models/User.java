package models;

import service.Search;

public class User {
    int userId;
    Search searchObj;
}
