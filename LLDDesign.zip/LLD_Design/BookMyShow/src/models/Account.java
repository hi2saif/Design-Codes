package models;

public class Account {
    String userName;
    String password;
}
