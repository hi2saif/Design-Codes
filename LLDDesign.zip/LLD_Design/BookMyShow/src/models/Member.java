package models;

import service.Booking;

import java.util.List;

public class Member extends SystemMember {
    public Booking makeBooking(Booking booking) {
        return null;
    }

    public List<Booking> getBooking() {
        return null;
    }
}
