import java.util.Date;

public class Fine {
    private Date creationDate;
    private double bookItemBarcode;
    private String memberId;

    public static void collectFine(String memberId, long days) {}
}
