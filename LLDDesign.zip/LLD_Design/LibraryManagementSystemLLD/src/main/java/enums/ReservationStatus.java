package enums;

public enum ReservationStatus {
    WAITING,
    PENDING,
    CANCELED,
    NONE
}
