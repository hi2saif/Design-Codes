package enums;

public enum BookStatus {
    AVAILABLE,
    RESERVED,
    LOANED,
    LOST
}
