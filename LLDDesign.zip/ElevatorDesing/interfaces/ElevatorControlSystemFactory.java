package ElevatorDesing.interfaces;

public interface ElevatorControlSystemFactory {
    public void pickUp(Integer pickUpFloor);
    public void destination(Integer elevatorId, Integer destinationFloor);   //adding desitnation floor in particular ele
    public void step();    //If I press button then what will be the status
}
