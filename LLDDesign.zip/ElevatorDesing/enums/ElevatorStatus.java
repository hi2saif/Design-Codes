package ElevatorDesing.enums;

public enum ElevatorStatus {
    ELEVATOR_OCCUPIED,
    ELEVATOR_EMPTY;
}
