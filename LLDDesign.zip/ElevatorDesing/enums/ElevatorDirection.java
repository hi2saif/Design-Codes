package ElevatorDesing.enums;

public enum ElevatorDirection {
    ELEVATOR_UP,
    ELEVATOR_DOWN,
    ELEVATOR_HOLD
}
