package ElevatorDesing.exception;

public class InvalidNumber extends Exception {
    public InvalidNumber(String msg) {
        super(msg);
    }
}
