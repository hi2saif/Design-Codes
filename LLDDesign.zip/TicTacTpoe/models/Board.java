package TicTacTpoe.models;

public class Board {
    private int[][] board;
    private int size;

    public int[][] getBoard() {
        return board;
    }

    public void setBoard(int[][] board) {
        this.board = board;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public Board(int size) {
        this.size = size;
        this.board = new int[size][size];
    }


}
