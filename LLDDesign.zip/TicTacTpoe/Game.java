package TicTacTpoe;

import TicTacTpoe.models.Board;

import java.util.Random;

public class Game {
    private Board board;
    private int isGameComplete;
    private int currPlayer;
    private int[] row;
    private int[] col;
    private int dialSum;
    private int revDiagSum;
    private int draw = 0;
    private int runCount = 0;

    public Game(Board board, int isGameComplete, int currPlayer) {
        this.board = board;
        this.isGameComplete = isGameComplete;
        this.currPlayer = currPlayer;
        row = new int[board.getSize()];
        col = new int[board.getSize()];
        dialSum = 0;
        revDiagSum = 0;
    }

    public int isGameCompleted() {
        return isGameComplete;
    }

    public void startGame() throws Exception {
        while (isGameCompleted() == 0 && draw == 0) {
            int row = new Random().nextInt(board.getSize());
            int col = new Random().nextInt(board.getSize());
            movePlayer(currPlayer, row, col);
            if (currPlayer == 0)
                currPlayer = 1;
            else
                currPlayer = 0;
        }
        if (draw == 1)
            System.out.println("The Game is drawn");
        return;
    }

    private void movePlayer(int currPlayer, int row1, int col1) throws Exception {
        if (row1 < 0 || row1 > board.getSize() || col1 < 0 || col1 > board.getSize()) {
            throw new Exception("Invalid position");
        }
        if (currPlayer != 0 && currPlayer != 1) {
            throw new Exception("Invalid Player");
        }
        if (board.getBoard()[row1][col1] != 0) {
            return;
        }
        if (runCount > board.getSize() * board.getSize())
            draw = 1;
        if (currPlayer == 0)
            currPlayer = -1;
        board.getBoard()[row1][col1] = currPlayer;
        row[row1] = row[row1] + currPlayer;
        col[col1] = col[col1] + currPlayer;
        if (row1 == col1)
            dialSum = dialSum + 1;
        if (row1 == board.getSize() - 1 - col1)
            revDiagSum = revDiagSum + 1;
        runCount++;
        if (row[row1] == Math.abs(board.getSize()) || col[col1] == Math.abs(board.getSize()) || dialSum == Math.abs(board.getSize()) ||
                revDiagSum == Math.abs(board.getSize())) {
            System.out.println("Won by" + currPlayer);
            isGameComplete = 1;
        }
    }
}
