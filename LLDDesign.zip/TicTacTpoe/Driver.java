package TicTacTpoe;

import TicTacTpoe.models.Board;

public class Driver {
    public static void main(String[] args) throws Exception {
        Board board = new Board(3);
        Game game1 = new Game(board, 0, 0);
        game1.startGame();
    }
}
