package ThreadMainApplication;

import java.util.concurrent.Semaphore;

public class OddEven {
    private static Semaphore oddSemaphore;
    private static Semaphore evenSemaphore;
    private static int count;
    private static int num;

    public OddEven() {
        oddSemaphore = new Semaphore(1);
        evenSemaphore = new Semaphore(0);
        count = 1;
        num = 20;
    }

    private static void print()
    {

    }

    private static void printOdd() throws InterruptedException {
        for (int i = 1; i <= num / 2; i++) {
            oddSemaphore.acquire();
            System.out.println("Printed Number Odd is :" + count);
            count++;
            evenSemaphore.release();
        }
    }

    private static void printEven() throws InterruptedException {
        for (int i = 1; i <= num / 2; i++) {
            evenSemaphore.acquire();
            System.out.println("Printed Number Even is :" + count);
            count++;
            oddSemaphore.release();
        }
    }

    public static class OddThread extends Thread {

        @Override
        public void run() {
            try {
                printOdd();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static class EvenThread extends Thread {

        @Override
        public void run() {
            try {
                printEven();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        OddEven oddEven = new OddEven();
        Thread t1 = new OddThread();
        Thread t2 = new EvenThread();
        t1.start();
        t2.start();
    }
}
