package ThreadMainApplication.MSQuestion;


import java.util.List;
import java.util.Random;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * In a cloud system,there is a critical resource, a which can only support only N connection request at any time.
 * If there are more requesst to the resource then all connection are degraded.
 * There are M callers which can use the resource and M>N
 * Implenent a locking mechanism so that the callers can safely access the resource.
 * You have SQL DB accessible to all the M nodes which all M nodes can access anytime.
 */
public class CloudSystem {
    private static Semaphore semaphore;
    public static int connection;
    public static int criticalResource;
    public List<Thread> threadArrayList;
    public static int resource;
    public static Lock lock;
    public static Random random = new Random();

    public CloudSystem(int M, List<Thread> threadArrayList, int N) {
        semaphore = new Semaphore(N);
        connection = 0;
        this.threadArrayList = threadArrayList;
        resource = N;
        lock = new ReentrantLock();
    }

    public static void AccessResource() throws InterruptedException {
            lock.lock();
            boolean isLastThread = false;
            try {
                connection++;
                System.out.println("Resource is acquired by " + Thread.currentThread().getName());
                if (connection == resource) {
                    isLastThread = true;
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                lock.unlock();
            }
            if (isLastThread) {
                System.out.println("No resource is left Wating .....");
                semaphore.release();
            } else {
                try {
                    semaphore.acquire();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

    }
}
