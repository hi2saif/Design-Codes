package ThreadMainApplication.MSQuestion;

import java.util.ArrayList;
import java.util.List;

public class Driver {

    public static void main(String[] args) {
        List<Thread> threadArrayList = new ArrayList<>(5);
        for (int i = 0; i < 5; i++) {
            threadArrayList.add(new threadClass());
        }
        threadArrayList.get(0).setName("First");
        threadArrayList.get(1).setName("Second");
        threadArrayList.get(2).setName("Third");
        threadArrayList.get(3).setName("Fourth");
        threadArrayList.get(4).setName("Fifth");
        CloudSystem cloudSystem = new CloudSystem(5,threadArrayList,3);
        for (int i = 0; i < 5; i++) {
           threadArrayList.get(i).start();
        }
    }
}

