package ThreadMainApplication.MSQuestion;

public class threadClass extends Thread {
    @Override
    public void run() {
        try {
            CloudSystem.AccessResource();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
