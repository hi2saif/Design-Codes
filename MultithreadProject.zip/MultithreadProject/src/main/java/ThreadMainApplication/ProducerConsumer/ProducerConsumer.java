package ThreadMainApplication.ProducerConsumer;

import java.util.LinkedList;

public class ProducerConsumer {
    int count = 0;
    LinkedList<Integer> list = new LinkedList<>();
    public void consume() throws InterruptedException {
        while (true) {
            synchronized (this) {
                while (list.size() == 0)
                    wait();
                int val = list.removeFirst();
                System.out.println("Consumed Element is " + val);
                notify();
                Thread.sleep(1000);
            }
        }
    }

    public void produce() throws InterruptedException {
        while (true) {
            synchronized (this) {
                while (list.size() >= 3) {
                    wait();
                }
                list.add(count);
                System.out.println("Produced Element is " + count);
                count++;
                notify();
                Thread.sleep(1000);
            }
        }
    }
}
